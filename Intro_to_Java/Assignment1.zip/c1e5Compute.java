/*
 * Author: Wen Wei Zheng
 * Course: CS 501 - Intro to JAVA Programming 
 * Textbook: 10th Edition 
 * Assignment 1 Question 1.5
 */

public class c1e5Compute {
	public static void main(String[] args) {
		System.out.println((9.5*4.5-2.5*3)/(45.5-3.5));
	}
}
